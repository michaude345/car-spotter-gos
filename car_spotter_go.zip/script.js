
const camera = document.getElementById("camera");
const carList = document.getElementById("carList");
let model;
let spottedCars = [];

// 📦 Liste de modèles rares
const rareCars = [
  "Bugatti",
  "Ferrari",
  "McLaren",
  "Lamborghini",
  "DeLorean",
  "Supra",
  "Skyline"
];

async function startCamera() {
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ video: true });
    camera.srcObject = stream;
  } catch (error) {
    alert("Caméra non disponible.");
  }
}

// 🔍 Charger le modèle IA MobileNet
async function loadModel() {
  model = await mobilenet.load();
  console.log("Modèle MobileNet chargé.");
}

// 📸 Scanner manuellement avec input texte
function scanCar() {
  const input = document.getElementById("carInput").value.trim();
  if (!input) {
    alert("Entre un nom de voiture !");
    return;
  }

  let isRare = rareCars.some((brand) =>
    input.toLowerCase().includes(brand.toLowerCase())
  );
  let points = isRare ? 100 : 10;

  spottedCars.push({ name: input, points });

  updateCarList();
  document.getElementById("carInput").value = "";
}

// 📸 Scanner automatiquement avec IA sur vidéo
async function scanCarAuto() {
  if (!model) {
    alert("Le modèle IA n'est pas encore chargé, attends un peu...");
    return;
  }
  const prediction = await model.classify(camera);
  if (prediction.length > 0) {
    const name = prediction[0].className;
    const isRare = rareCars.some((brand) =>
      name.toLowerCase().includes(brand.toLowerCase())
    );
    const points = isRare ? 100 : 10;

    spottedCars.push({ name, points });
    updateCarList();
  } else {
    alert("Aucune voiture détectée.");
  }
}

function updateCarList() {
  carList.innerHTML = "";
  spottedCars.forEach((car) => {
    const li = document.createElement("li");
    li.textContent = `${car.name} → ${car.points} pts`;
    carList.appendChild(li);
  });
}

// 📦 Initialisation
startCamera();
loadModel();
